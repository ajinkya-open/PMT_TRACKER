import paho.mqtt.client as mqtt

#############################
##  DB
import MySQLdb
# Open database connection

###########################


def checkTopics(topicName,msg):

    try:
        db = MySQLdb.connect("localhost", "root", "root", "TESTDB")

        sql = "SELECT TOPIC_LOCATION FROM TOPICS WHERE TOPIC_NAME='" + str(topicName) + "'"
        print "[QUERY] HIT : " + sql
        cursor = db.cursor()
        cursor.execute(sql)
        topic_location = cursor.fetchall()
        topic_location = topic_location[0][0]
        print topic_location
        splittedLocations=topic_location.split(',')
        everyStop=splittedLocations
        everyStop[0]=everyStop[1]
        everyStop[1] = everyStop[2]
        everyStop[2] = everyStop[3]
        everyStop[3] = everyStop[4]
        everyStop[4] = msg
        newString=everyStop[0]+","+everyStop[1]+","+everyStop[2]+","+everyStop[3]+","+everyStop[4]
        cursor.close()


        cursor=db.cursor()
        sql = "UPDATE TOPICS SET TOPIC_LOCATION='"+newString+"' WHERE TOPIC_NAME='"+topicName+"'"
        print "[QUERY] HIT : " + sql
        cursor.execute(sql)


        db.commit()
        cursor.close()
        db.close()
        print "inserted new record"
    except Exception as e:
        print e
        return "cant access database"
        db.rollback()


def on_connect(client, userdata, flags, rc):
    client.subscribe("#")
    print "[INFO] subsciption done"

def on_message(client, userdata, msg):
    print(msg.topic+" "+str(msg.payload))
    checkTopics(msg.topic,str(msg.payload))


client = mqtt.Client()
client.on_message = on_message
client.on_connect = on_connect

client.connect("localhost", 1883, 60)

client.loop_forever()

